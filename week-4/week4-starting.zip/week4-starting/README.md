Code template for Connections Lab class Week 4

Code template for Connections Lab class, IMA Low Res Fall 2025.
